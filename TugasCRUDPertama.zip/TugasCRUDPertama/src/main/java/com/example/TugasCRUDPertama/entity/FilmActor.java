/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.TugasCRUDPertama.entity;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapsId;
import javax.persistence.Table;

/**
 *
 * @author admin
 */
@Entity
public class FilmActor implements Serializable {
    
   @EmbeddedId
   FilmActorKey id;
   
   @ManyToOne
   @MapsId("actor_Id")
   @JoinColumn(name="actor_id")
   Actor actor;
   
   @ManyToOne
   @MapsId("film_Id")
   @JoinColumn(name="film_id")
   Film film;

    public FilmActor() {
    }

    public FilmActor(FilmActorKey id, Actor actor, Film film) {
        this.id = id;
        this.actor = actor;
        this.film = film;
    }

    public FilmActorKey getId() {
        return id;
    }

    public void setId(FilmActorKey id) {
        this.id = id;
    }

    public Actor getActor() {
        return actor;
    }

    public void setActor(Actor actor) {
        this.actor = actor;
    }

    public Film getFilm() {
        return film;
    }

    public void setFilm(Film film) {
        this.film = film;
    }

    
   

  
}
