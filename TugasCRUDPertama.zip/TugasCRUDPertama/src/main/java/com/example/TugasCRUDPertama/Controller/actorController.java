/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.TugasCRUDPertama.Controller;

import com.example.TugasCRUDPertama.Repository.actorRepo;
import com.example.TugasCRUDPertama.entity.Actor;
import com.example.TugasCRUDPertama.entity.FilmActor;
import com.example.TugasCRUDPertama.services.ActorServices;
import java.util.List;
import java.util.Optional;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

/**
 *
 * @author admin
 */
@Controller
public class actorController {

    @Autowired
    ActorServices actorService;

    @Autowired
    actorRepo actorRepo;
    
 

    @GetMapping("/actor")
    public String actor(Model model) {
        model.addAttribute("dataActor", actorService.findAllActor());
        return "actor";
    }

    @GetMapping("/actor/create")
    public String showForm(Model model) {
        model.addAttribute("actor", new Actor());
        return "formActor";
    }

    @PostMapping("/addActor")
    public String addActor(@Valid Actor actor) {
        actor.setActorId(0);
        actor.setVersionId('1');
        actorRepo.save(actor);
        return "redirect:/actor";

    }

    @GetMapping("/actor/edit/{actorId}")
    public String showEditForm(Model model, @PathVariable("actorId") int actId) {
        Actor dataActor = actorRepo.getOne(actId);
        model.addAttribute("actor", dataActor);
        System.out.println(dataActor.getFirstName());
        System.out.println(dataActor.getLastName());
        return "formEditActor";
    }

    @PostMapping("/editActor")
    public String updateActor(@Valid Actor a,
            @RequestParam("actorId") int acID,
            @RequestParam("firstName") String firstName,
            @RequestParam("lastName") String lastName
    ) {
        Actor dataActor = actorRepo.getOne(acID);
        dataActor.setFirstName(firstName);
        dataActor.setLastName(lastName);
        actorRepo.save(dataActor);
        return "redirect:/actor";

    }

    @GetMapping("/deleteActor/{actorId}")
    public String deleteActor(Model model,@PathVariable("actorId") int actorId){
        Actor dataActor = actorRepo.getOne(actorId);
        model.addAttribute("actor", dataActor);
        actorRepo.delete(dataActor);
        return "redirect:/actor";

    }
    
  
}
