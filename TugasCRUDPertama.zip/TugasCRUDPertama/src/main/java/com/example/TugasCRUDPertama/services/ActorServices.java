/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.TugasCRUDPertama.services;

import com.example.TugasCRUDPertama.Repository.actorRepo;
import com.example.TugasCRUDPertama.entity.Actor;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author admin
 */
@Service
public class ActorServices {

    @Autowired
    private actorRepo actorRepo;

    public Iterable<Actor> findAllActor() {
        return actorRepo.findAllActors();
    }

    public Actor getOne(int id) {
        return actorRepo.getOne(id);
    }
    
    

}
