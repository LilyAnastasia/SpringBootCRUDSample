/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.TugasCRUDPertama.entity;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 *
 * @author admin
 */
@Embeddable
public class FilmActorKey implements Serializable {
    
    @Column(name = "actor_id")
    int actorId;
    
    @Column(name = "film_id")
    int filmId;
    
    
    
}
