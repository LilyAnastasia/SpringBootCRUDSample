/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.TugasCRUDPertama.Repository;

import com.example.TugasCRUDPertama.entity.Film;
import java.util.List;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

/**
 *
 * @author admin
 */
@Repository
public interface filmRepo extends CrudRepository<Film, Integer> {
    @Query(value = "SELECT * FROM film "
           ,nativeQuery = true)
    List<Film> findAllFilm();
    
    @Query(value = "SELECT * FROM film where film_id=? "
           ,nativeQuery = true)
    Film getFilmById(int id);
}
