/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.TugasCRUDPertama.services;

import com.example.TugasCRUDPertama.Repository.filmRepo;
import com.example.TugasCRUDPertama.entity.Actor;
import com.example.TugasCRUDPertama.entity.Film;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author admin
 */
@Service
public class FilmServices {
    @Autowired
    private filmRepo FilmRepo;
    
    public Iterable<Film> FindAllFilms(){
        return FilmRepo.findAllFilm();
    }
    
    public Film getFilmById(int id) {
        return FilmRepo.getFilmById(id);
    }
}
