/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.TugasCRUDPertama.Controller;

import com.example.TugasCRUDPertama.Repository.filmRepo;
import com.example.TugasCRUDPertama.entity.Actor;
import com.example.TugasCRUDPertama.services.FilmServices;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import com.example.TugasCRUDPertama.entity.Film;
import java.math.BigDecimal;
import java.util.Date;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 *
 * @author admin
 */
@Controller
public class filmController {
    @Autowired
    private FilmServices filmService;

    @Autowired
    private filmRepo FilmRepo;

    @GetMapping("/film")
    public String film(Model model) {
        model.addAttribute("dataFilm", filmService.FindAllFilms());
        return "film";
    }
    
   @GetMapping("/film/create")
    public String showFormFilm(Model model){
        model.addAttribute("film", new Film());
        return "formFilm";
    }
  @PostMapping("/addFilm")
    public String addFilm(@Valid Film film) {
        film.setFilmId(0);
        film.setLanguageId('1');
        FilmRepo.save(film);
        return "redirect:/film";

    }
    
    @GetMapping("/film/edit/{filmId}")
    public String showEditForm(Model model, @PathVariable("filmId") int id) {
        Film dataFilm = FilmRepo.getFilmById(id);
        model.addAttribute("film",dataFilm );
        
        return "formEditFilm";
    }
    
   @PostMapping("/editFilm")
    public String updateFilm(@Valid Film f,
            @RequestParam("filmId") int id,
            @RequestParam("title") String title,
            @RequestParam("rentalDuration") short rentalDuration,
            @RequestParam("rentalRate") BigDecimal rentalRate,
            @RequestParam("replacementCost") BigDecimal replacementCost
    ) {
        Film dataFilm = FilmRepo.getFilmById(id);
        dataFilm.setTitle(title);
        dataFilm.setRentalDuration(rentalDuration);
        dataFilm.setRentalRate(rentalRate);
        dataFilm.setReplacementCost(replacementCost);
        FilmRepo.save(dataFilm);
        return "redirect:/film";

    }
    
    /*@GetMapping("/deleteFilm/{filmId}")
    public String deleteFilm(Model model,@PathVariable("filmId") int IdFilm){
        Film dataFilm = FilmRepo.getFilmById(IdFilm);
        model.addAttribute("film", dataFilm);
        FilmRepo.delete(dataFilm);
        return "redirect:/actor";

    }*/
}
